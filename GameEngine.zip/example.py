import GameEngine as engine
engine.spawn_platform(0,15,0,15,"concrete")
print(engine.export_map())