from ctypes import *
from platform import architecture
arch=architecture()
if arch[0]=='32bit':
	engine=windll.LoadLibrary("GameEngine.dll")
elif arch[0]=='64bit':
	engine=windll.LoadLibrary("GameEngine64.dll")
def game_engine_version():
	return str(engine.get_ver1())+"."+str(engine.get_ver2())+"."+str(engine.get_ver3())+". build "+str(engine.get_ver4())
engine.spawn_platform2D.argtypes=(c_int,c_int,c_int,c_int,c_char_p)
def spawn_platform(min_x,max_x,min_y,max_y,platform_type):
	engine.spawn_platform2D(min_x,max_x,min_y,max_y,platform_type.encode('mbcs'))
engine.spawn_platform3D.argtypes=(c_int,c_int,c_int,c_int,c_int,c_int,c_char_p)
def spawn_platform3d(min_x,max_x,min_y,max_y,min_z,max_z,platform_type):
	engine.spawn_platform3D(min_x,max_x,min_y,max_y,min_z,max_z,platform_type.encode('mbcs'))
engine.spawn_zone2D.argtypes=(c_int,c_int,c_int,c_int,c_char_p)
def spawn_zone(min_x,max_x,min_y,max_y,zone):
	engine.spawn_zone2D(min_x,max_x,min_y,max_y,zone.encode('mbcs'))
engine.spawn_zone3D.argtypes=(c_int,c_int,c_int,c_int,c_int,c_int,c_char_p)
def spawn_zone3d(min_x,max_x,min_y,max_y,zone):
	engine.spawn_zone3D(min_x,max_x,min_y,max_y,min_z,max_z,zone.encode('mbcs'))
engine.get_tile_at2D.restype=c_char_p
def get_tile_at(x,y):
	return engine.get_tile_at2D(x,y).decode('mbcs')
engine.get_tile_at3D.restype=c_char_p
def get_tile_at3d(x,y,z):
	return engine.get_tile_at3D(x,y,z).decode('mbcs')
engine.get_zone_at2D.restype=c_char_p
def get_zone_at(x,y):
	return engine.get_zone_at2D(x,y).decode('mbcs')
engine.get_zone_at3D.restype=c_char_p
def get_zone_at3d(x,y,z):
	return engine.get_zone_at3D(x,y,z).decode('mbcs')
engine.export_map.restype=c_char_p
def export_map():
	return engine.export_map().decode('mbcs')
engine.import_map.argtypes=(c_char_p,)
def import_map(mapdata):
	engine.import_map(mapdata.encode('mbcs'))
engine.export_zones.restype=c_char_p
def export_zones():
	return engine.export_zones().decode('mbcs')
def clear_map():
	engine.clear_map()
def clear_zones():
	engine.clear_zones()
def map_length():
	return engine.map_length()
def zones_length():
	return engine.zones_length()
def start_recording_audio():
	engine.start_recording_audio()
engine.stop_recording_audio.argtypes=(c_int,c_char_p)
def stop_recording_audio(filename):
	engine.stop_recording_audio(0,filename.encode('mbcs'))
engine.download_file.argtypes=(c_char_p,)
def download_file(url):
	engine.download_file(url.encode('mbcs'))
engine.download_file_as.argtypes=(c_char_p,c_char_p)
def download_file_as(url,filename):
	engine.download_file_as(url.encode('mbcs'),filename.encode('mbcs'))
engine.download_file_string.argtypes=(c_char_p,)
engine.download_file_string.restype=c_char_p
def download_file_string(url):
	return engine.download_file_string(url.encode('mbcs')).decode('mbcs')
"""as of the time of this writing, ftp functions don't work yet. Also, you have an ftp lib in python.
def ftp_connect(server, port=21):
	return engine.ftp_connect(server,port)
def ftp_disconnect():
	return engine.ftp_disconnect()
def ftp_receive(filename):
	return engine.ftp_receive(filename)
def ftp_receive_as(filename,target):
	return engine.ftp_receive_as(filename,target)
def ftp_send(filename):
	return engine.ftp_send(filename)
def ftp_send_as(filename,target):
	return engine.ftp_send_as(filename,target)
def ftp_directory_set(dir):
	return engine.ftp_directory_set(dir)
def ftp_directory_get(dir):
	return engine.ftp_directory_get(dir)
def ftp_directory_create(dir):
	return engine.ftp_directory_create(dir)
def ftp_directory_delete(dir):
	return engine.ftp_directory_delete(dir)
def ftp_file_delete(file):
	return engine.ftp_file_delete(file)
def ftp_file_rename(file,newfile):
	return engine.ftp_file_rename(file,newfile)
def ftp_get_directories():
	return engine.ftp_get_directories().split("\r\n")
def ftp_get_files():
	return engine.ftp_get_files().split("\r\n")
"""
def reader(title,text,defaulttext,okname="OK"):
	engine.reader(title,text,defaulttext,okname)
def notify(title,text,okname="OK"):
	engine.notify(title,text,okname)
def reg_exp_match(the_string, pattern):
	engine.reg_exp_match(the_string, pattern)
def reg_exp_replace(the_string, pattern,replacement):
	engine.reg_exp_replace(the_string, pattern,replacement)