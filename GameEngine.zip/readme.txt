Welcome to the masonasons Game Engine!

** Powering SBYW (Scrolling Battles, Your World!)

This game engine's main purpose is to make it quick, efficient, and easy to create game environments. It also has a few extra functions to help with other things such as recording audio and downloading files. It is constantly being updated with bug fixes and other new functions. It has the BGT user in mind, but will work on any programming language you choose, as well as both Mac OS and Windows. It comes with an example wrapper coded in BGT, which you can use to either code with the engine in BGT or create a new wrapper in a language of your choosing.

Functions

string load_engine()
This function is specific to the BGT wrapper, and must be called in order to use the engine successfully. It returns a string of the game engine version.

int get_ver1();
Returns the major version number of the game engine.
example: 0

int get_ver2();
Returns the minor version number of the game engine.
example: 5

int get_ver3();
Returns the beta/alpha/bugfix version number of the game engine.
example: 0

int get_ver4();
Returns the build  number of the game engine.
example: 51

void spawn_platform2D(int min_x,int max_x,int min_y,int max_y,char* platform_type);
spawns a 2D platform. Note: 2D and 3D functions cannot be used in conjunction with each other.
perametors
min_x: the minimum x position of the platform.
max_x: the maximum x position of the platform.
min_y: the minimum y position of the platform.
max_y: the maximum y position of the platform.
platform_type: The platform type, such as dirt or fence.

void spawn_platform3D(int min_x,int max_x,int min_y,int max_y,int min_z,int max_z,char* platform_type);
spawns a 3D platform. Note: 2D and 3D functions cannot be used in conjunction with each other.
perametors
min_x: the minimum x position of the platform.
max_x: the maximum x position of the platform.
min_y: the minimum y position of the platform.
max_y: the maximum y position of the platform.
min_z: the minimum z position of the platform.
max_z: the maximum z position of the platform.
platform_type: The platform type, such as dirt or fence.

void spawn_zone2D(int min_x,int max_x,int min_y,int max_y,char* zone);
spawns a 2D zone. Zones are used to name an area. Note: 2D and 3D functions cannot be used in conjunction with each other.
perametors
min_x: the minimum x position of the zone.
max_x: the maximum x position of the zone.
min_y: the minimum y position of the zone.
max_y: the maximum y position of the zone.
zone: The name of the zone, such as back yard.

void spawn_zone3D(int min_x,int max_x,int min_y,int max_y,int min_z,int max_z,char* zone);
spawns a 3D zone. Zones are used to name an area. Note: 2D and 3D functions cannot be used in conjunction with each other.
perametors
min_x: the minimum x position of the zone.
max_x: the maximum x position of the zone.
min_y: the minimum y position of the zone.
max_y: the maximum y position of the zone.
min_z: the minimum z position of the zone.
max_z: the maximum z position of the zone.
zone: The name of the zone, such as back yard.

string get_tile_at2D(int x, int y);
return the name of the tile at the specified 2D position. Note: 2D and 3D functions cannot be used in conjunction with each other.
example: dirt

string get_tile_at3D(int x,int y,int z);
return the name of the tile at the specified 3D position. Note: 2D and 3D functions cannot be used in conjunction with each other.
example: dirt

string get_zone_at2D(int x, int y);
return the name of the zone at the specified 2D position. Note: 2D and 3D functions cannot be used in conjunction with each other.
example: back yard

string get_zone_at3D(int x,int y,int z);
return the name of the zone at the specified 3D position. Note: 2D and 3D functions cannot be used in conjunction with each other.
example: back yard

string export_map()
Export the currently spawned map as human readable data that can then be encrypted, saved to a file, etc.

void import_map(char* mapdata);
Import a previously exported map.

string export_zones()
Export the currently spawned zone data as human readable data that can then be encrypted, saved to a file, etc.

void import_zones(char* mapdata);
Import previously exported zone data.

void clear_map()
reset the current map.

void clear_zones()
reset the current zone data.

int map_length()
return current map size.
example: 42

int zones_length()
return current zone data size.
example: 42


void start_recording_audio()
Starts recording audio from the default audio source. Note: This function currently only works on Windows.

void start_recording_audio()
Starts recording audio from the default audio source. Note: This function currently only works on Windows.

void stop_recording_audio(int convert, char* filename)
Stops recording audio.
perametors
convert: currently does nothing, but in the future will be used to select if the file should be converted from wave to another filetype.
filename: The filename you'd like the file to be saved as.


void download_file(char* url);
Download a file from the web. Will save with the name given by the URL.

void download_file_as(char* url,char* filename);
Download a file from the web. Will save with the name given by the filename perametor.

string download_file_string(char* url);
Download a file from the web. Will save directly into a string for manual saving or manipulation.

int ftp_connect(char* server, int port, char* username, char* password)
Connects to an FTP server.
server: URL to an FTP server.
port: Usually 21, an FTP port
username: your FTP username. If none, use ""
password: your FTP password. If none, use ""
returns: 0 for success, non0 for failure.

int ftp_disconnect()
Disconnects from the previously connected FTP server.
Returns: 0 for success, non0 for failure.

int ftp_receive(char* filename)
Receives an FTP file to your machine.
Returns: 0 for success, non0 for failure.

int ftp_receive_as(char* filename, char* target)
Receives an FTP file to your machine with a custom filename.
Returns: 0 for success, non0 for failure.

int ftp_send(char* filename)
Send a file to the FTP server.
returns: 0 for success, non0 for failure.

int ftp_send_as(char* filename, char* target)
Send a file to the FTP server with a custom filename.
returns: 0 for success, non0 for failure.

int ftp_directory_set(char* dir)
Sets the currently browsing/sending/receiving FTP directory.
returns: 0 for success, non0 for failure.

string ftp_directory_get()
Gets the currently set FTP Directory.
Returns: a string with the current directory.

int ftp_directory_create(char* dir)
Creates a new directory on the server.

int ftp_directory_delete(char* dir)
Deletes a directory on the server.

int ftp_file_delete(char* file)
Deletes a file on the server

int ftp_file_rename(char* file, char* newfile)
Renames a file on the server.

string ftp_get_directories()
Returns a newline delimited string containing the directories on the current FTP directory.

string ftp_get_files()
Returns a newline delimited string containing the files on the current FTP directory.

Note: The BGT versions of these 2 functions return arrays.


string open_file_select(string title, string defaultpath, string pattern, int position)
Create an open file dialog and return the contents.
In BGT, this function returns an array of files. The DLL itself returns a crlf separated list of files.
pattern example: "All files (*.*)|*.*|MP3 files (*.mp3)|*.mp3"

int reg_exp_match(string the_string, string pattern)
match a regular expression to a string. Returns 1 if yes, 0 if no. In bgt, returns true or false.

string reg_exp_replace(string the_string, string pattern, string replacement)
Replace a string based on a regular expression.
returns the replaced string.

void show_runtime_errors(int show)
Toggles showing PB runtime errors

void zip_create(string filename)
Creates a zip file with the specified filename.

void zip_open(string filename)
Opens an existing zip file.

void zip_close()
Close the already opened zip file.

void zip_add(string filename)
Adds a file to the zip with the specified filename.

void zip_add_as(string filename, string filename2)
Adds a file to the zip with a custom filename.

void zip_extract_file(string filename, string filename2)
Extract a file from the zip.

string[] zip_get_files()
Get a list of files from the zip.
Returns a crlf delimited string, in bgt returns an array.

I hope this engine is useful to you!